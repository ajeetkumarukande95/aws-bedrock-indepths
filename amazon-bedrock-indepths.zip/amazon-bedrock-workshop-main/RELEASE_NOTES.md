### 2/18/2024
- TO DO


### 2/15/2024

- new 'basic' set up and testing which removes the need for bedrock utils folder. All notebooks now just use default boto3 bedrock/bedrock-runtime
- Some notebooks have moved as is, and others have been merged. Making sure instructions in the notebook are still correct (markdown sections) is important
- Open source examples (Langchain, Nemo)  have been moved to a separate folder. Some existing PRs can be fixed and tested directly here. Once we test it we can resolve those PRs and point to the new release.
- Fine tuning and other new feature examples are needed
- Pending Major PRs
    - https://github.com/aws-samples/amazon-bedrock-workshop/pull/194
    - https://github.com/aws-samples/amazon-bedrock-workshop/pull/187
    - https://github.com/aws-samples/amazon-bedrock-workshop/pull/149
    - https://github.com/aws-samples/amazon-bedrock-workshop/pull/107
    
    
### 2/10/2024
- Major structural changes
- working branch is BR-workshop-v2